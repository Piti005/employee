import csv
import os
from datetime import datetime, timedelta
import employee

VACATIONS_CSV = "vacations.csv"

VACATIONS_DATA = [
    "employee_id",
    "employee_name",
    "vacation_start_date",
    "end_date_vacation",
    "calculated_days",
    "condition",
    "month",
    "year"]

 # create csv
def create_csv():

    if not os.path.exists(VACATIONS_CSV):
        with open(VACATIONS_CSV, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames= VACATIONS_DATA)
            writer.writeheader()
 
#read request
 
def read_requests() -> list:
   
    create_csv ()

    with open(VACATIONS_CSV, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return list(reader)
    
    #Save csv

def save_request(request: dict):
   
    create_csv()

    with open(VACATIONS_CSV, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=VACATIONS_DATA)
        writer.writerow(request)



    #months works
def months_works(initial_date: str) -> int:

    date = datetime.strptime(initial_date, "%Y-%m-%d")
    today = datetime.now()

    month = (today.year - date.year) * 12 + (today.month - date.month)

    # if the current month has not ended, - 1
    if today.day < date.day:
        month -= 1

    return max(0, month)


def available_vacation_days(employee_id: str) -> float:
 
    emp_data= None
    for e in employee.read_employees():
        if e["employee_id"] == employee_id:
            emp_data = e
            break

    if not emp_data:
        return 0
    months = months_works(emp_data["contract_start_date"])
    accumulated = months * 1.5

    requests = read_requests()

    used = sum (
        float (s["calculated_days"])
        for s in requests
        if s["employee_id"] == employee_id and s["condition"] == "APPROVED"
    )

    return accumulated - used


#no sundays

def days_without_sundays(start_date: str, end_date: str) -> int:
    

    start = datetime.strptime(start_date, "%Y-%m-%d")
    end = datetime.strptime(end_date, "%Y-%m-%d")

    if end < start:
        return -1

    day = 0
    act = start

    while act <= end:
        if act.weekday() != 6:  # 6 = domingo
            day += 1
        act += timedelta(days=1)

    return day

    # register
def register_request():
    print("\n=== REGISTER VACATION REQUEST ===\n")

    emp_id = input("Employee ID: ").strip()

    employees = None
    for e in employee.read_employees():
        if e["employee_id"] == emp_id:
            employees = e
            break

    if not employees:
        print("[!] There is no employee with that ID.")
        input("\nPress Enter to continue...")
        return

    # Validate minimum months
    month = months_works(employees["contract_start_date"])
    if month < 6:
        print(f"[!] The employee only has {month} Months worked. Minimum allowed: 6 months.")
        input("\nPress Enter to continue...")
        return

    date_start = input("Vacation start date (YYYY-MM-DD): ").strip()
    date_end = input("Vacation end date (YYYY-MM-DD): ").strip()

    # Counting days
    days_requested = days_without_sundays(date_start, date_end)

    if days_requested <= 0:
        print("[!] Invalid dates.")
        input("\nPress Enter to continue...")
        return

    avialable = available_vacation_days(emp_id)

    if days_requested > avialable:
        print(f"[!] Days requested: {days_requested}. Available days: {avialable:.2f}.")
        input("\nPress Enter to continue...")
        return

    # Create request
    request = {
        "employee_id": emp_id,
        "employee_name": employees["full_name"],
        "vacation_start_date": date_start,
        "end_date_vacation": date_end,
        "calculated_days": days_requested,
        "condition": "PENDING",
        "month": date_start.split("-")[1],
        "year": date_start.split("-")[0]
    }

    save_request(request)

    print("\n[i] Application successfully registered.")
    input("\nPress Enter to continue...")

def list_pending():
    print("\n--- PENDING APPLICATIONS ---\n")

    requests = read_requests()
    pending = [s for s in requests if s["condition"] == "PENDING"]

    if not pending:
        print("[i] There are no pending applications..")
        input("\nPress Enter to continue...")
        return

    for s in pending:
        print(f"ID: {s['employee_id']} | {s['employee_name']} | {s['vacation_start_date']} -> {s['end_date_vacation']} | {s['calculated_days']} days")

    return pending

def approve_reject():
    requests = list_pending()
    if not requests:
        return

    emp_id = input("\n Enter the ID of the employee to be processed: ").strip()

    progress = False

    for s in requests:
        if s["employee_id"] == emp_id:
            print("\n1) APPROVED")
            print("2) REJECTED")
            print("0) Cancel")
            op = input("Choose an option: ").strip()

            if op == "1":
                s["condition"] = "APPROVED"
                progress = True
            elif op == "2":
                s["condition"] = "REJECTED"
                progress = True
            else:
                print("[i] Cancel.")
                input("\nPress Enter to continue...")
                return

    if progress:
        # save all
        all = read_requests()
        for i, reg in enumerate(all):
            for s in requests:
                if reg["employee_id"] == s["employee_id"] and reg["vacation_start_date"] == s["vacation_start_date"]:
                    all[i] = s

        with open(VACATIONS_CSV, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=VACATIONS_DATA)
            writer.writeheader()
            writer.writerows(all)

        print("\n[i] condition successfully updated.")
        input("\nPress Enter to continue...")


def employee_history():
    print("\n=== VACATIONS HISTORY ===\n")

    emp_id = input("Employee ID: ").strip()
    requests = read_requests()

    history = [s for s in requests if s["employee_id"] == emp_id]

    if not history:
        print("[i] There are no applications for this employee.")
        input("\nPress Enter to continue...")
        return

    for s in history:
        print(f"{s['vacation_start_date']} -> {s['end_date_vacation']} | {s['calculated_days']} day | Status: {s['condition']}")

    input("\nPress Enter to continue...")



def vacations_menu():
    while True:
        os.system("cls" if os.name == "nt" else "clear")
        print("--------------------------------------")
        print("     VACATIONS MANAGEMENT")
        print("--------------------------------------")
        print("1) Register request")
        print("2) Approve/Reject requests")
        print("3) Employee history")
        print("0) Return to main menu")
        print("-------------------------------------")

        op = input("Choose an option: ").strip()

        if op == "1":
            register_request()
        elif op == "2":
            approve_reject()
        elif op == "3":
            employee_history()
        elif op == "0":
            return
        else:
            print("Invalid option.")
            input("\nPress Enter to continue...")

