import csv
import os

USERS_CSV = "users.csv"

def validate_credentials (user: str, password: str) -> dict | None:
    if not os.path.exists(USERS_CSV):
        print(f"[!] file {USERS_CSV} no found.")
        return None
    
    with open(USERS_CSV, mode="r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row.get("user") == user and row.get("password") == password:
                return row

    return None

def list_user():
    if not os.path.exists(USERS_CSV):
        print("[!] The file users.csv does not exist")
        input("\nPress Enter to continue...")
        return

    print("\n=== LIST OF REGISTERED USERS ===\n")
    with open(USERS_CSV, mode="r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            user = row.get("user", "")
            rol = row.get("rol", "")
            print(f" - User: {user} | Rol: {rol}")

    input("\nLIST OF REGISTERED USERS...")

def get_user(user: str) -> dict | None:
    if not os.path.exists(USERS_CSV):
        return None

    with open(USERS_CSV, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row.get("user") == user:
                return row

    return None

