import csv
import os
import employee
import vacation

def generate_report():
    print("\n=== GENERATE VACATION REPORT ===\n")

    month = input("Enter the month (1-12): ").strip()
    year = input("Enter the year (YYYY): ").strip()

    # Validaciones
    if not month.isdigit() or not (1 <= int(month) <= 12):
        print("[!] Invalid month.")
        input("\nPress Enter to continue...")
        return

    if not year.isdigit() or len(year) != 4:
        print("[!] Invalid year.")
        input("\nPress Enter to continue...")
        return

    request = vacation.read_requests()

    approved = [
        s for s in request
        if s["condition"] == "APPROVED" and s["month"] == month.zfill(2) and s["year"] == year
    ]

    if not approved:
        print("[i] There are no approved applications for that period.")
        input("\nPress Enter to continue...")
        return

    # Unimos con datos del empleado para incluir cargo y área
    list_employee = {e["employee_id"]: e for e in employee.read_employees()}

    file_name = f"report_vacations_{year}_{month.zfill(2)}.csv"

    with open(file_name, "w", newline="", encoding="utf-8") as f:
        fieldnames = [
            "employee_id",
            "employee_name",
            "job",
            "area",
            "vacation_start_date",
            "end_date_vacation",
            "calculated_days",
            "month",
            "year"
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

        for s in approved:
            emp = list_employee.get(s["employee_id"], {})
            fila = {
                "employee_id": s["employee_id"],
                "employee_name": s["employee_name"],
                "job": emp.get("job", ""),
                "area": emp.get("area", ""),
                "vacation_start_date": s["vacation_start_date"],
                "end_date_vacation": s["end_date_vacation"],
                "calculated_days": s["calculated_days"],
                "month": s["month"],
                "year": s["year"]
            }
            writer.writerow(fila)

    print(f"\n[i] Report successfully generated: {file_name}")
    input("\nPress Enter to continue...")


def report_menu():
    while True:
        os.system("cls" if os.name == "nt" else "clear")
        print("=====================================")
        print("      REPORT GENERATION")
        print("=====================================")
        print("1) Generate report by month and year")
        print("0) Return to main menu")
        print("-------------------------------------")

        opcion = input("Choose an option: ").strip()

        if opcion == "1":
            generate_report()
        elif opcion == "0":
            return
        else:
            print("Invalid option.")
            input("\nPress Enter to continue...")