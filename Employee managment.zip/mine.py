import csv
import os
import sys
import getpass

import users
import employee
import vacation
import report

USERS_CSV = "users.csv"

USERS_DATA = {
    "user": "Riwitl",
    "password": "riwi123",
    "rol" : "TeamLeader"
}

def create_users():
    
    if not os.path.exists(USERS_CSV):
        print("[i] No users.csv file found, creating default file...")

        with open(USERS_CSV, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["user", "password", "rol"])
            writer.writeheader()
            writer.writerow(USERS_DATA)

def load_user(user: str, password: str):
    
    return users.validate_credentials(user, password)

def clear_console():
    os.system("cls" if os.name == "nt" else "clear")


def pause():
    input("\nPress Enter to continue...")


def show_users_csv():
    users.list_user()

def main_menu(user: dict):
  

    while True:
        clear_console()
        print("---------------------------------------------")
        print("        PeopleOS Vacation Console")
        print("---------------------------------------------")
        print(f"  Session started as: {user['user']} (rol: {user['rol']})")
        print("============================================\n")

        print("1) Employee Management")
        print("2) Vacation requests")
        print("3) Reports (CSV)")
        print("4) List users")
        print("5) Log out")
        print("0) Exit the program")
        print("--------------------------------------------")

        op = input("Choose an option: ").strip()

        if op == "1":
            employee.employee_menu()

        elif op == "2":
            vacation.vacations_menu()

        elif op == "3":
            report.report_menu()

        elif op == "4":
            users.list_user()

        elif op == "5":
            print("\n[i] Logging out...")
            pause()
            return  

        elif op == "0":
            print("\n[i] Logging out of the system. Goodbye!")
            sys.exit(0)

        else:
            print("\n[!] Invalid option.")
            pause()

def login_screen():
    attempts = 3

    while attempts > 0:
        clear_console()
        print("------------------------------------------")
        print("        PeopleOS Vacation Console")
        print("                LOGIN")
        print("------------------------------------------\n")

        user = input("User: ").strip()
        password = getpass.getpass("Password: ").strip()

        user= load_user(user, password)

        if user:
            print(f"\n[i] Welcome, {user['user']}.")
            pause()
            main_menu(user)
            return 
        else:
            attempts -= 1
            print("\n[!] Incorrect credentials.")
            print(f"[i] Remaining attempts: {attempts}")
            pause()

    print("\n[!] Attempts exhausted. Exiting...")
    sys.exit(1)

def main():
    create_users()
    login_screen()


if __name__ == "__main__":
    main()
