import csv
import os
from datetime import datetime

EMPLOYEE_CSV = "employee.csv"


EMPLOYEE_DATA = [
    "employee_id",
    "full_name",
    "job",
    "area",
    "contract_start_date"
]


    # create csv
def create_csv ():
    if not os.path.exists(EMPLOYEE_CSV):
        with open(EMPLOYEE_CSV, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames= EMPLOYEE_DATA)
            writer.writeheader()
    
    #read 

def read_employees() -> list:
    
    create_csv()

    with open (EMPLOYEE_CSV, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return list(reader) 

    # Save csv

def save_employee(employee: dict):
    
    create_csv()

    with open(EMPLOYEE_CSV, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames= EMPLOYEE_DATA)
        writer.writerow(employee)

    # Register
def register_employee():
    print("\n---- REGISTER EMPLOYEE ----\n")

    employee_id = input("Employee ID: ").strip()
    name = input("Full name: ").strip()
    job = input("Job: ").strip()
    area = input("Area: ").strip()
    start_date= input("Contract start date (YYYY-MM-DD): ").strip()

    # Date 
    try:
        datetime.strptime(start_date, "%Y-%m-%d")
    except ValueError:
        print("[!] Invalid date. Correct format: YYYY-MM-DD")
        input("\nPress Enter to continue...")
        return
    
    #duble ID

    employee = read_employees()
    for emp in employee:
        if emp["employee_id"] == employee_id:
            print("[!] That ID already exists. It cannot be registered.")
            input("\nPress Enter to continue...")
            return
        
    # new employee        
    new = {
        "employee_id": employee_id,
        "full_name": name,
        "job": job,
        "area": area,
        "contract_start_date": start_date
    }

    save_employee (new)
    print("\n[i] Employee registered correctly.")
    input("\nPress Enter to continue...")


    #lIST OF EMPLOYEE
def list_employees():
    
    print("\n=== LIST OF EMPLOYEES ===\n")

    employee = read_employees()
    if not employee:
        print("[i] There are no registered employees.")
        input("\nPress Enter to continue...")
        return

    for emp in employee:
        print(f"{emp['employee_id']} - {emp['full_name']} | {emp['job']} | {emp['area']}")

    input("\nPress Enter to continue...")

    #Search

def search_employee():
    
    print("\n--- SEARCH EMPLOYEE ---\n")

    emp_id = input("Enter employee ID: ").strip()
    employee = read_employees()

    for emp in employee:
        if emp["employee_id"] == emp_id:
            print("\n--- Employee Information ---")
            for k, v in emp.items():
                print(f"{k}: {v}")
            input("\nPress Enter to continue...")
            return

    print("[!] There is no employee with that ID..")
    input("\nPress Enter to continue...")



#       Menu

def employee_menu():
    
    while True:
        os.system("cls" if os.name == "nt" else "clear")
        print("--------------------------------------")
        print("      EMPLOYEE MANAGEMENT")
        print("--------------------------------------")
        print("1) Register employee")
        print("2) List employees")
        print("3) Consult employee")
        print("0) Return to main menu")
        print("-------------------------------------")

        opt = input("Choose an option: ").strip()

        if opt == "1":
          register_employee()

        elif opt == "2":
            list_employees()

        elif opt == "3":
            search_employee()

        elif opt == "0":
            return
        else:
            print("Invalid option.")
            input("\nPress Enter to continue...")

